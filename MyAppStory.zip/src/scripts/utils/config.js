// src/scripts/utils/config.js

// Key untuk akses token di localStorage (PENTING: Gunakan 'token' konsisten)
export const ACCESS_TOKEN_KEY = 'token';

// Base URL API Dicoding
export const BASE_URL = 'https://story-api.dicoding.dev/v1';

// API Key tambahan untuk Maps
export const MAP_SERVICE_API_KEY = 'L1V7oYaAoswTHnKhMMJ8';

// VAPID Public Key untuk Push Notification
export const VAPID_PUBLIC_KEY = 'BCCs2eonMI-6H2ctvFaWg-UYdDv387Vno_bzUzALpB442r2lCnsHmtrx8biyPi_E-1fSGABK_Qs_GlvPoJJqxbk';